package com.scrapper;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NewsScrapperApplication {

	public static void main(String[] args) {
		SpringApplication.run(NewsScrapperApplication.class, args);
	}

}
