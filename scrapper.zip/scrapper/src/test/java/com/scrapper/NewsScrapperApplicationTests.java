package com.scrapper;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NewsScrapperApplicationTests {

	@Test
	void contextLoads() {
	}

}
